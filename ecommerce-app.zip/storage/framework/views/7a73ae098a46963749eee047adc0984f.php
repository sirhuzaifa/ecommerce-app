<form method="post" action="<?php echo e(route('category.store')); ?>">
    <?php echo csrf_field(); ?>
    <input type="text" name="name" id="">
    <textarea name="description" id=""></textarea>
    <button type="submit">Submit</button>
</form><?php /**PATH C:\Users\asp\Documents\ecommerce-app\resources\views/dashboard/category/add.blade.php ENDPATH**/ ?>