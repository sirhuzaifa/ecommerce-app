<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <Form method="post" action="<?php echo e(url('/form/store')); ?>">
        <?php echo csrf_field(); ?>
        <input type="text" name="username">
        <button type="submit">Submit</button>
    </Form>
</body>
</html><?php /**PATH C:\Users\asp\Documents\ecommerce-app\resources\views/form.blade.php ENDPATH**/ ?>